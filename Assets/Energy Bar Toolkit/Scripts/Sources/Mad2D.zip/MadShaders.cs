/*
* Energy Bar Toolkit by Mad Pixel Machine
* http://www.madpixelmachine.com
*/

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace EnergyBarToolkit {

public class MadShaders {

    // ===========================================================
    // Constants
    // ===========================================================
    
    public const string UnlitTint = "Energy Bar Toolkit/Unlit/Transparent Tint";
    public const string UnlitTintPre = "Energy Bar Toolkit/Unlit/Transparent Tint Pre";
    public const string Font = "Energy Bar Toolkit/Unlit/Font";
    public const string FontWhite = "Energy Bar Toolkit/Unlit/Font White";

    // ===========================================================
    // Fields
    // ===========================================================

    // ===========================================================
    // Methods for/from SuperClass/Interfaces
    // ===========================================================

    // ===========================================================
    // Methods
    // ===========================================================

    void Start() {
    }

    void Update() {
    }

    // ===========================================================
    // Static Methods
    // ===========================================================

    // ===========================================================
    // Inner and Anonymous Classes
    // ===========================================================

}

} // namespace